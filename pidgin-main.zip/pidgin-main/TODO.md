## Functionality
- [x] Options page to set Are.na channel to save likes / bookmarks to
- [x] Send back tweet type (favorite / bookmark) as response
- [x] Are.na channel validation
- [x] User flow to set up extension (logging in, setting channels, etc.)

## Design
- [x] HTML page for options / auth
- [x] Inject iframe & match og Are.na extension

## Documentation
- [x] Finish README
- [ ] Clean code
- [ ] Naming parity